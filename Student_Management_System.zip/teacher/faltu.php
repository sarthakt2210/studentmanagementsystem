<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="teacherdash.css">
    <title>Document</title>
</head>
<body>
    <div class="intro_name">
        <h2 data-text="creative...">creative...</h2>
    </div>
</body>
</html>