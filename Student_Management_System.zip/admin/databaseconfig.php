<?php
session_start();

$con = mysqli_connect('sql209.epizy.com','epiz_27763464','sO58YyOsgsq','epiz_27763464_management');

?>